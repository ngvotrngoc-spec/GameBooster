package com.fc.booster

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var pkgBox: EditText
    private lateinit var hzBox: EditText
    private lateinit var out: TextView
    private val pkg get() = pkgBox.text.toString().trim()
    private val hz get() = hzBox.text.toString().trim().ifEmpty { "120" }

    private fun sh(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val r = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor(); r.trim()
    } catch (e: Throwable) { "Lỗi: ${e.message}" }

    private fun act(l: LinearLayout, t: String, f: () -> String) {
        l.addView(Button(this).apply { text = t; setOnClickListener {
            out.text = "Đang chạy..."
            Thread { val r = f(); runOnUiThread { out.text = r.ifBlank { "Xong" } } }.start() } })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        pkgBox = EditText(this).apply { setText("com.garena.game.fcmobilevn"); hint = "Package game" }
        hzBox = EditText(this).apply { setText("120"); hint = "Tần số quét (Hz)" }
        out = TextView(this).apply { setTextIsSelectable(true); text = "Kết quả sẽ hiện ở đây" }
        l.addView(pkgBox); l.addView(hzBox)

        l.addView(Button(this).apply { text = "1. Cấp quyền Shizuku"; setOnClickListener {
            if (!Shizuku.pingBinder()) out.text = "Shizuku chưa chạy. Mở app Shizuku và khởi động trước."
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) out.text = "Đã có quyền Shizuku"
            else Shizuku.requestPermission(100)
        } })

        act(l, "TỐI ƯU TẤT CẢ + MỞ GAME") {
            val r = StringBuilder()
            r.append("Chế độ hiệu năng: ").append(sh("cmd game mode performance $pkg 2>&1; cmd game mode $pkg 2>&1 | head -3")).append("\n")
            r.append("Tắt tiết kiệm pin: ").append(sh("settings put global low_power 0 && echo ok")).append("\n")
            r.append("Tắt hiệu ứng: ").append(sh("settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0; echo ok")).append("\n")
            r.append("Tần số quét ${hz}Hz: ").append(sh("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz; echo ok")).append("\n")
            r.append("Dọn RAM: ").append(sh("am kill-all; echo ok")).append("\n")
            sh("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
            r.append("Đã mở game")
            r.toString()
        }
        act(l, "Dọn RAM (kill app nền)") { sh("am kill-all; echo Đã dọn") + "\n" + sh("grep -E 'MemTotal|MemAvailable' /proc/meminfo") }
        act(l, "Bật chế độ hiệu năng (Game Mode)") { sh("cmd game mode performance $pkg 2>&1; cmd game mode $pkg 2>&1 | head -5") }
        act(l, "Tắt hiệu ứng hệ thống") { sh("settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0; echo Đã tắt") }
        act(l, "Ép tần số quét cao") { sh("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz; echo Đã đặt ${hz}Hz (tuỳ máy có hỗ trợ)") }
        act(l, "Biên dịch sẵn game (vào nhanh hơn, ~1-3 phút)") { sh("cmd package compile -m speed -f $pkg 2>&1") }
        act(l, "Xem nhiệt độ + RAM + pin") {
            sh("grep -E 'MemTotal|MemAvailable' /proc/meminfo; dumpsys battery | grep -E 'level|temperature'") +
                "\n(temperature chia 10 = độ C)"
        }
        act(l, "KHÔI PHỤC MẶC ĐỊNH") {
            sh("cmd game mode standard $pkg 2>&1; settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1; settings delete system min_refresh_rate; settings delete system peak_refresh_rate; echo Đã khôi phục")
        }
        l.addView(out)
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
